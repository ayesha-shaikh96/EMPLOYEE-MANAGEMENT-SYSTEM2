package com.springboot.employee.service;

import java.util.List;

import com.springboot.employee.entity.Attendance;


public interface AttendanceService 
{
	List<Attendance> getAllAttendance();
	
	Attendance saveAttendance(Attendance attendance);
		
	Attendance getAttendanceById(long id);
		
		void deleteAttendanceById(long id);

}
