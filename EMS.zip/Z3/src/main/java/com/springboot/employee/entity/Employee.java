package com.springboot.employee.entity;



import java.util.List;

import jakarta.persistence.*;






@Entity
@Table(name="employee")
public class Employee {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long employeeId;

	  
	    @Column(name="name", nullable = false)
	    private String name;

	    @Column(name="dateOfBirth", nullable = false)
	    private String dateOfBirth;

	    @Column(name="gender", nullable = false)
	    private String gender;

	    @Column(name="contactNumber", nullable = false)
	    private String contactNumber;

	    @Column(name="email", nullable = false)
	    private String email;

	    @Column(name="address", nullable = false)
	    private String address;

	    @Column(name="designation", nullable = false)
	    private String designation;

	    @Column(name="joiningDate", nullable = false)
	    private String joiningDate;


    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL)
    private List<Salary> salaries;

    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL)
    private List<Attendance> attendances;

    @ManyToOne
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;

    public Long getDepartmentId() {
        return department != null ? department.getDepartmentId() : null;
    }
    public Employee()
    {
    	
    }

	public Employee(Long employeeId, String name, String dateOfBirth, String gender, String contactNumber, String email,
			String address, String designation, String joiningDate, List<Salary> salaries, List<Attendance> attendances,
			Department department) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.contactNumber = contactNumber;
		this.email = email;
		this.address = address;
		this.designation = designation;
		this.joiningDate = joiningDate;
		this.salaries = salaries;
		this.attendances = attendances;
		this.department = department;
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}

	public List<Salary> getSalaries() {
		return salaries;
	}

	public void setSalaries(List<Salary> salaries) {
		this.salaries = salaries;
	}

	public List<Attendance> getAttendances() {
		return attendances;
	}

	public void setAttendances(List<Attendance> attendances) {
		this.attendances = attendances;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}
    
    
    
    
}
