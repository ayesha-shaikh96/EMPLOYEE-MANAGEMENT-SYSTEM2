package com.springboot.employee.entity;




import java.time.Month;

import jakarta.persistence.*;

@Entity
@Table(name="salary")
public class Salary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long salaryId;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;
    

    @Column(name="basicSalary", nullable = false)
    private double basicSalary;
    
   
    
    @Column(name = "bonus", nullable = false)
    private double bonus;
    
    @Column(name="deduction", nullable = false)
    private double deductions;
    
    @Column(name="netSalary", nullable = false)
    private double netSalary;
    
    @Column(name="month", nullable = false)
    private Month month;
    
    @Column(name="year", nullable = false)
    private int year;
    
    
    
    public Salary()
    {
    	
    }



	public Salary(Long salaryId, Employee employee, double basicSalary, double bonus, double deductions,
			double netSalary, Month month, int year) {
		super();
		this.salaryId = salaryId;
		this.employee = employee;
		this.basicSalary = basicSalary;
		this.bonus = bonus;
		this.deductions = deductions;
		this.netSalary = netSalary;
		this.month = month;
		this.year = year;
	}



	public Long getSalaryId() {
		return salaryId;
	}



	public void setSalaryId(Long salaryId) {
		this.salaryId = salaryId;
	}



	public Employee getEmployee() {
		return employee;
	}



	public void setEmployee(Employee employee) {
		this.employee = employee;
	}



	public double getBasicSalary() {
		return basicSalary;
	}



	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}



	public double getBonus() {
		return bonus;
	}



	public void setBonus(double bonus) {
		this.bonus = bonus;
	}



	public double getDeductions() {
		return deductions;
	}



	public void setDeductions(double deductions) {
		this.deductions = deductions;
	}



	public double getNetSalary() {
		return netSalary;
	}



	public void setNetSalary(double netSalary) {
		this.netSalary = netSalary;
	}



	public Month getMonth() {
		return month;
	}



	public void setMonth(Month month) {
		this.month = month;
	}



	public int getYear() {
		return year;
	}



	public void setYear(int year) {
		this.year = year;
	}

    
    
    
    
    
}
