package com.springboot.employee.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.employee.entity.Employee;
import com.springboot.employee.repository.EmployeeRepository;
import com.springboot.employee.service.EmployeeService;

@Service
public class EmployeeImpl implements EmployeeService 
{
	
	private EmployeeRepository emprepo;
	
	

	public EmployeeImpl(EmployeeRepository emprepo) {
		super();
		this.emprepo = emprepo;
	}

	
	
	
	@Override
	public List<Employee> getAllEmployee() {
		
		return emprepo.findAll();
	}

	@Override
	public Employee saveEmployee(Employee employee) {
		
		return emprepo.save(employee);
	}

	@Override
	public Employee getEmployeeById(long id) {
		
		return emprepo.findById(id).get();
	}

	@Override
	public void deleteEmployeeById(long id) 
	{
		emprepo.deleteById(id);
		
		
	}




	@Override
	public Employee getEmployeeByName(String name) {
		// TODO Auto-generated method stub
		return emprepo.findByName(name);
	}




	
	
	
	
	
	

}

