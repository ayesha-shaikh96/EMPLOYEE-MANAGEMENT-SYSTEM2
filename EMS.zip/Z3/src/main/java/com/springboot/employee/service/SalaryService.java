package com.springboot.employee.service;

import java.util.List;


import com.springboot.employee.entity.Salary;

public interface SalaryService 
{
	
	  List<Salary> getAllSalary();
		
	  Salary saveSalary(Salary salary);
		
	  Salary getSalaryById(long id);
		
		void deleteSalaryById(long id);


}
